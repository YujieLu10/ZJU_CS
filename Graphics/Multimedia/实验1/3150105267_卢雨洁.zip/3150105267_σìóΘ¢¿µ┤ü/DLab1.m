function en = DLab1()
f = randperm(255, 50);
[~,n] = size(f);
f1 = zeros(1,n);
f2 = zeros(1,n);
e = zeros(1,n);
en = zeros(1,n);
 
f1(1) = f(1);
f1(2) = f(1);
e(1) = 0;
en(1) = 0;
f2(1) = f(1);
 
for i = 2:n
    if(i~=2)
        f1(i) = ( f2(i-1)+f2(i-2) )/2;
    end
    e(i) = f(i) - f1(i);
    en(i) = 16*trunc((255 + e(i))/16)-256+8;
    f2(i) = en(i) + f1(i);
end
x1 = 1; x2 = 50;
x = x1 : x2;
plot(x, f2, 'g--');
hold on;
plot(x, f, 'r');

end
 
function out = trunc(in)
if(in>0)
    out = floor(in);
elseif (in<0)
    out = ceil(in);
else
    out = 0;
end
end

